import requests
from datadog_checks.base import AgentCheck

STATUS_LABELS = [
    "Scheduled", "Running", "Completed", "Failed", "Cancelled", "Late", "Paused", "Pending"
]


class PrefectCheck(AgentCheck):
    SERVICE_CHECK_NAME = "prefect.api.health"

    def __init__(self, name, init_config, instances):
        super().__init__(name, init_config, instances)
        self.api_url = self.instance.get("api_url", "").rstrip("/")
        self.api_key = self.instance.get("api_key")
        self.timeout = self.instance.get("timeout", 5)
        self.prefect_api_version = None
        self.headers = {}

    def check(self, _):
        # Always fetch or refresh the Prefect API version
        self._ensure_api_version()

        self._check_health()
        self._collect_status_counts("flow_runs", "prefect.flow_runs")
        self._collect_status_counts("task_runs", "prefect.task_runs")
        self._collect_flow_run_metrics()
        self._collect_deployment_metrics()
        self._collect_work_queue_metrics()
        self._collect_concurrency_metrics()

    def _ensure_api_version(self):
        """Fetches the Prefect API version if not already set."""
        if self.prefect_api_version is None:
            try:
                resp = requests.get(
                    f"{self.api_url}/version", timeout=self.timeout)
                resp.raise_for_status()
                self.prefect_api_version = resp.json().get(
                    "prefect", "2.0.0")  # fallback to something sane
                self.headers = {
                    "X-Prefect-API-Version": self.prefect_api_version,
                }
                if self.api_key:
                    self.headers["Authorization"] = f"Bearer {self.api_key}"
                self.log.info(
                    f"Using Prefect API version: {self.prefect_api_version}")
            except Exception as e:
                self.log.error(f"Failed to fetch Prefect API version: {e}")
                self.prefect_api_version = "2.0.0"  # Default to 2.0.0 if broken

    def _check_health(self):
        try:
            resp = requests.get(f"{self.api_url}/health",
                                headers=self.headers, timeout=self.timeout)
            resp.raise_for_status()
            self.service_check(self.SERVICE_CHECK_NAME, self.OK)
        except Exception as e:
            self.log.error(f"Health check failed: {e}")
            self.service_check(self.SERVICE_CHECK_NAME, self.CRITICAL)

    def _collect_status_counts(self, endpoint, metric_prefix):
        for status in STATUS_LABELS:
            try:
                response = requests.post(
                    f"{self.api_url}/{endpoint}/count",
                    json={"filters": {"state": {"name": {"any_": [status]}}}},
                    headers=self.headers,
                    timeout=self.timeout
                )
                response.raise_for_status()
                count = response.json()  # raw int in Prefect 3
                self.gauge(f"{metric_prefix}.status", count,
                           tags=[f"status:{status.lower()}"])
            except Exception as e:
                self.log.warning(
                    f"Failed to fetch {endpoint} for status {status}: {e}")

    def _collect_flow_run_metrics(self):
        try:
            response = requests.post(
                f"{self.api_url}/flow_runs/lateness",
                json={"filters": {}},
                headers=self.headers,
                timeout=self.timeout
            )
            response.raise_for_status()
            lateness_data = response.json()
            avg_lateness = lateness_data.get(
                "lateness", {}).get("average_seconds", 0)
            self.gauge("prefect.flow_runs.lateness.avg_seconds", avg_lateness)
        except Exception as e:
            self.log.warning(f"Failed to fetch flow run lateness: {e}")

    def _collect_deployment_metrics(self):
        try:
            response = requests.post(
                f"{self.api_url}/deployments/filter",
                json={"limit": 1000},
                headers=self.headers,
                timeout=self.timeout
            )
            response.raise_for_status()
            deployments = response.json()
            self.gauge("prefect.deployments.total", len(deployments))

            active = sum(1 for d in deployments if d.get(
                "is_schedule_active", False))
            for d in deployments:
                flow_id = d.get("flow_id", "unknown")
                tags = [f"flow:{flow_id}"]
                if d.get("is_schedule_active"):
                    self.gauge("prefect.deployments.active", 1, tags=tags)
        except Exception as e:
            self.log.warning(f"Failed to fetch deployments: {e}")

    def _collect_work_queue_metrics(self):
        try:
            response = requests.post(
                f"{self.api_url}/work_queues/filter",
                json={"limit": 1000},
                headers=self.headers,
                timeout=self.timeout
            )
            response.raise_for_status()
            queues = response.json()
            self.gauge("prefect.work_queues.total", len(queues))
        except Exception as e:
            self.log.warning(f"Failed to fetch work queues: {e}")

    def _collect_concurrency_metrics(self):
        try:
            response = requests.post(
                f"{self.api_url}/concurrency_limits/filter",
                json={"limit": 1000},
                headers=self.headers,
                timeout=self.timeout
            )
            response.raise_for_status()
            limits = response.json()
            self.gauge("prefect.concurrency_limits.total", len(limits))

            for limit in limits:
                tag = limit.get("tag", "unknown")
                active = limit.get("active_slots", 0)
                self.gauge("prefect.concurrency_limits.active_slots",
                           active, tags=[f"tag:{tag}"])
        except Exception as e:
            self.log.warning(f"Failed to fetch concurrency limits: {e}")
